fx_version 'cerulean'
game 'gta5'

author 'S'
description 'Persistent körförbud för ESX med fri placering och medföljande prop.'
version '1.1.1'

shared_scripts {
    '@ox_lib/init.lua',
    'config.lua'
}

client_scripts {
    'client/dataview.lua',
    'client/gizmo.lua',
    'client/main.lua'
}

server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'server/main.lua'
}

files {
    'stream/sb_korforbud.ytyp'
}

data_file 'DLC_ITYP_REQUEST' 'stream/sb_korforbud.ytyp'

dependencies {
    'es_extended',
    'ox_lib',
    'oxmysql'
}
