local ESX = exports['es_extended']:getSharedObject()
local dbReady = false
local commandCooldown = {}

local CREATE_TABLE = [[
CREATE TABLE IF NOT EXISTS `s_korforbud` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `plate` VARCHAR(16) NOT NULL,
    `display_plate` VARCHAR(16) NOT NULL,
    `model_hash` BIGINT NOT NULL,
    `offset_x` DOUBLE NOT NULL,
    `offset_y` DOUBLE NOT NULL,
    `offset_z` DOUBLE NOT NULL,
    `qx` DOUBLE NOT NULL,
    `qy` DOUBLE NOT NULL,
    `qz` DOUBLE NOT NULL,
    `qw` DOUBLE NOT NULL,
    `officer_identifier` VARCHAR(80) DEFAULT NULL,
    `officer_name` VARCHAR(100) DEFAULT NULL,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uniq_plate` (`plate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
]]

local function trim(value)
    return (value and value:match('^%s*(.-)%s*$')) or ''
end

local function normalizePlate(plate)
    return trim(tostring(plate or '')):upper():gsub('%s+', '')
end

local function isFinite(n)
    return type(n) == 'number' and n == n and math.abs(n) < 100000.0
end

local function isPolice(source)
    local xPlayer = ESX.GetPlayerFromId(source)
    if not xPlayer or not xPlayer.job then return false, xPlayer end
    return Config.AllowedJobs[xPlayer.job.name] == true, xPlayer
end

local function notify(source, message, notifyType)
    TriggerClientEvent('S_Korforbud:notify', source, message, notifyType or 'inform')
end

local function rateLimited(source, key, milliseconds)
    local now = GetGameTimer()
    commandCooldown[source] = commandCooldown[source] or {}
    local untilTime = commandCooldown[source][key] or 0
    if now < untilTime then return true end
    commandCooldown[source][key] = now + milliseconds
    return false
end

local function serializeRow(row)
    if not row then return nil end
    return {
        id = tonumber(row.id),
        plate = normalizePlate(row.plate),
        display_plate = row.display_plate,
        model_hash = tonumber(row.model_hash),
        offset_x = tonumber(row.offset_x),
        offset_y = tonumber(row.offset_y),
        offset_z = tonumber(row.offset_z),
        qx = tonumber(row.qx),
        qy = tonumber(row.qy),
        qz = tonumber(row.qz),
        qw = tonumber(row.qw),
        officer_name = row.officer_name,
        created_at = row.created_at
    }
end

local function getNetworkVehicle(netId)
    netId = tonumber(netId)
    if not netId or netId <= 0 then return 0 end
    local entity = NetworkGetEntityFromNetworkId(netId)
    if not entity or entity == 0 or not DoesEntityExist(entity) then return 0 end
    if GetEntityType(entity) ~= 2 then return 0 end
    return entity
end

local function validatePlayerNearEntity(source, entity, maxDistance)
    local ped = GetPlayerPed(source)
    if not ped or ped == 0 or not DoesEntityExist(ped) then return false end
    local p = GetEntityCoords(ped)
    local e = GetEntityCoords(entity)
    return #(p - e) <= maxDistance
end

CreateThread(function()
    while GetResourceState('oxmysql') ~= 'started' do Wait(250) end
    MySQL.query.await(CREATE_TABLE)
    dbReady = true
    print('^2[S_Korforbud]^7 Databastabellen är redo.')
end)

local function sendSync(source)
    if not dbReady then
        CreateThread(function()
            while not dbReady do Wait(100) end
            sendSync(source)
        end)
        return
    end

    local rows = MySQL.query.await('SELECT * FROM `s_korforbud`') or {}
    local payload = {}
    for i = 1, #rows do payload[#payload + 1] = serializeRow(rows[i]) end
    TriggerClientEvent('S_Korforbud:sync', source, payload)
end

RegisterNetEvent('S_Korforbud:requestSync', function()
    sendSync(source)
end)

local function runPoliceAction(source, eventName)
    if source == 0 then return end

    local allowed = isPolice(source)
    if not allowed then
        notify(source, 'Du måste vara polis för att använda detta kommando.', 'error')
        return
    end

    if rateLimited(source, eventName, 800) then return end
    TriggerClientEvent(eventName, source)
end

local function registerPoliceCommand(name, eventName)
    RegisterCommand(name, function(source)
        runPoliceAction(source, eventName)
    end, false)
end

RegisterNetEvent('S_Korforbud:requestCommand', function(action)
    local eventName

    if action == 'place' then
        eventName = 'S_Korforbud:beginPlacement'
    elseif action == 'remove' then
        eventName = 'S_Korforbud:beginRemoval'
    else
        return
    end

    runPoliceAction(source, eventName)
end)

registerPoliceCommand('körförbud', 'S_Korforbud:beginPlacement')
registerPoliceCommand('korforbud', 'S_Korforbud:beginPlacement')
registerPoliceCommand('tabortkörförbud', 'S_Korforbud:beginRemoval')
registerPoliceCommand('tabortkorforbud', 'S_Korforbud:beginRemoval')

RegisterNetEvent('S_Korforbud:save', function(data)
    local source = source
    if not dbReady or type(data) ~= 'table' then return end

    local allowed, xPlayer = isPolice(source)
    if not allowed or not xPlayer then return end
    if rateLimited(source, 'save', 1200) then return end

    local plate = normalizePlate(data.plate)
    local displayPlate = trim(data.display_plate)
    local modelHash = tonumber(data.model_hash)
    local values = {
        tonumber(data.offset_x), tonumber(data.offset_y), tonumber(data.offset_z),
        tonumber(data.qx), tonumber(data.qy), tonumber(data.qz), tonumber(data.qw)
    }

    if plate == '' or #plate > 16 or not modelHash then
        notify(source, 'Kunde inte spara: ogiltigt fordon.', 'error')
        return
    end

    for i = 1, #values do
        if not isFinite(values[i]) then
            notify(source, 'Kunde inte spara: ogiltig placering.', 'error')
            return
        end
    end

    local offsetLength = math.sqrt(values[1]^2 + values[2]^2 + values[3]^2)
    if offsetLength > Config.MaxAttachmentOffset + 0.15 then
        notify(source, 'Kunde inte spara: propen är för långt från fordonet.', 'error')
        return
    end

    local vehicle = getNetworkVehicle(data.net_id)
    if vehicle == 0 then
        notify(source, 'Kunde inte verifiera fordonet. Försök igen när du står nära bilen.', 'error')
        return
    end

    if not validatePlayerNearEntity(source, vehicle, Config.ServerValidationDistance) then
        notify(source, 'Du är för långt från fordonet.', 'error')
        return
    end

    local serverPlate = normalizePlate(GetVehicleNumberPlateText(vehicle))
    if serverPlate ~= plate or tonumber(GetEntityModel(vehicle)) ~= modelHash then
        notify(source, 'Fordonet ändrades under placeringen. Försök igen.', 'error')
        return
    end

    local existing = MySQL.scalar.await('SELECT `id` FROM `s_korforbud` WHERE `plate` = ? LIMIT 1', { plate })
    if existing then
        notify(source, 'Det fordonet har redan körförbud.', 'error')
        return
    end

    local officerIdentifier = xPlayer.identifier
    local officerName = xPlayer.getName and xPlayer.getName() or GetPlayerName(source)

    local id = MySQL.insert.await([[
        INSERT INTO `s_korforbud`
            (`plate`, `display_plate`, `model_hash`, `offset_x`, `offset_y`, `offset_z`, `qx`, `qy`, `qz`, `qw`, `officer_identifier`, `officer_name`)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ]], {
        plate,
        displayPlate ~= '' and displayPlate or plate,
        modelHash,
        values[1], values[2], values[3],
        values[4], values[5], values[6], values[7],
        officerIdentifier,
        officerName
    })

    if not id then
        notify(source, 'Databasen kunde inte spara körförbudet.', 'error')
        return
    end

    local row = MySQL.single.await('SELECT * FROM `s_korforbud` WHERE `id` = ?', { id })
    local serialized = serializeRow(row)
    if serialized then TriggerClientEvent('S_Korforbud:upsert', -1, serialized) end
    notify(source, ('Körförbud placerat på %s.'):format(displayPlate ~= '' and displayPlate or plate), 'success')
end)

RegisterNetEvent('S_Korforbud:remove', function(data)
    local source = source
    if not dbReady or type(data) ~= 'table' then return end

    local allowed = isPolice(source)
    if not allowed then return end
    if rateLimited(source, 'remove', 900) then return end

    local id = tonumber(data.id)
    local plate = normalizePlate(data.plate)
    if not id or plate == '' then return end

    local vehicle = getNetworkVehicle(data.net_id)
    if vehicle == 0 or not validatePlayerNearEntity(source, vehicle, Config.ServerValidationDistance) then
        notify(source, 'Du måste stå nära fordonet för att ta bort körförbudet.', 'error')
        return
    end

    if normalizePlate(GetVehicleNumberPlateText(vehicle)) ~= plate then
        notify(source, 'Kunde inte verifiera rätt fordon.', 'error')
        return
    end

    local affected = MySQL.update.await('DELETE FROM `s_korforbud` WHERE `id` = ? AND `plate` = ?', { id, plate })
    if not affected or affected < 1 then
        TriggerClientEvent('S_Korforbud:removed', -1, plate)
        notify(source, 'Körförbudet var redan borttaget.', 'inform')
        return
    end

    TriggerClientEvent('S_Korforbud:removed', -1, plate)
    notify(source, 'Körförbudet är borttaget permanent.', 'success')
end)

AddEventHandler('playerDropped', function()
    commandCooldown[source] = nil
end)
