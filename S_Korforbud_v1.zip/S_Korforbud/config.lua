Config = {}

Config.AllowedJobs = {
    police = true,
}

Config.PropModel = 'sb_korforbud'
Config.PlaceVehicleDistance = 5.0
Config.MaxAttachmentOffset = 3.5
Config.RemoveDistance = 4.0
Config.ServerValidationDistance = 8.0
Config.VehicleScanInterval = 900
Config.ModelLoadTimeout = 7000
Config.Debug = false
