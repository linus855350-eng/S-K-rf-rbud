# S_Korforbud

Gratis FiveM-resurs för permanenta körförbud på fordon i ESX. Placeringen sparas i databasen och återskapas när fordonet streamas in igen.

## Funktioner

- ESX Legacy
- ox_lib-notiser och TextUI
- Automatisk databasinstallation via oxmysql
- Körförbud kopplas till registreringsnummer och fordonsmodell
- Fri placering med inbyggd freecam och FiveM/Cfx-gizmo
- Sparad position och rotation följer fordonet
- Medföljande addon-prop
- Server-side validering vid placering och borttagning
- Stöd för flera tillåtna jobb via `Config.AllowedJobs`

## Krav

- `es_extended`
- `ox_lib`
- `oxmysql`

## Installation

1. Lägg mappen `S_Korforbud` i din resources-mapp.
2. Se till att kraven ovan startas före resursen.
3. Lägg till `ensure S_Korforbud` i `server.cfg`.
4. Starta servern eller resursen.

Databastabellen `s_korforbud` skapas automatiskt vid start.

## Kommandon

| Kommando | Funktion |
| --- | --- |
| `/körförbud` | Placera körförbud på närmaste fordon |
| `/korforbud` | Samma kommando utan å/ö |
| `/tabortkörförbud` | Ta bort närmaste körförbud |
| `/tabortkorforbud` | Samma kommando utan å/ö |

## Placering

När placeringen startar öppnas freecam-läget.

| Kontroll | Funktion |
| --- | --- |
| Mus | Titta runt |
| W/A/S/D | Flytta kameran |
| Q/E | Ner/upp |
| Shift | Snabbare kamera |
| Ctrl | Långsammare kamera |
| Scroll | Zoom |
| Left Alt | Växla mellan freecam och gizmo |
| W | Flyttläge i gizmo |
| R | Rotationsläge i gizmo |
| Q | Växla mellan lokal och world rotation/flytt |
| Enter | Spara placeringen |
| Esc | Avbryt |

## Konfiguration

All konfiguration finns i `config.lua`.

`Config.AllowedJobs` styr vilka ESX-jobb som får använda kommandona. Standard är `police`.

## Persistence

Resursen sparar registreringsnummer, fordonsmodell, lokal position och lokal quaternion-rotation. När samma fordon streamas in igen återskapas körförbudet på den sparade platsen.

## Licens

Projektet distribueras under MIT License. Se `LICENSE` och `THIRD_PARTY_NOTICES.txt`.
