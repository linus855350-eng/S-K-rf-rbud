local dataview = SKorforbudDataView

local gizmoEnabled = false
local currentEntity = nil
local currentFocusEntity = nil
local cancelled = false
local currentMode = 'Flytta'
local localMode = false
local freecam = nil
local camPos = vector3(0.0, 0.0, 0.0)
local camRot = vector3(0.0, 0.0, 0.0)
local camFov = 50.0
local cursorActive = false
local lastUiMode = nil
local gizmoId = 'S_Korforbud'

local FREECAM_SPEED = 3.0
local FREECAM_FAST_MULTIPLIER = 3.0
local FREECAM_SLOW_MULTIPLIER = 0.30
local FREECAM_MOUSE_SENSITIVITY = 7.5
local FREECAM_MIN_FOV = 22.0
local FREECAM_MAX_FOV = 70.0
local FREECAM_FOV_STEP = 2.5
local FREECAM_MAX_DISTANCE = 18.0

local function clamp(value, minValue, maxValue)
    if value < minValue then return minValue end
    if value > maxValue then return maxValue end
    return value
end

local function normalize(x, y, z)
    local length = math.sqrt(x * x + y * y + z * z)
    if length <= 0.000001 then
        return 0.0, 0.0, 0.0
    end
    return x / length, y / length, z / length
end

local function rotationToDirection(rotation)
    local pitch = math.rad(rotation.x)
    local yaw = math.rad(rotation.z)
    local cosPitch = math.abs(math.cos(pitch))

    return vector3(
        -math.sin(yaw) * cosPitch,
        math.cos(yaw) * cosPitch,
        math.sin(pitch)
    )
end

local function getRightVector(rotation)
    local yaw = math.rad(rotation.z)
    return vector3(math.cos(yaw), math.sin(yaw), 0.0)
end

local function releaseGizmoCommands()
    ExecuteCommand('-gizmoSelect')
    ExecuteCommand('-gizmoTranslation')
    ExecuteCommand('-gizmoRotation')
    ExecuteCommand('-gizmoLocal')
end

local function setNativeTranslationMode()
    currentMode = 'Flytta'
    ExecuteCommand('+gizmoTranslation')
    CreateThread(function()
        Wait(50)
        ExecuteCommand('-gizmoTranslation')
    end)
end

local function setCursor(enabled)
    if enabled and not cursorActive then
        EnterCursorMode()
        cursorActive = true
        setNativeTranslationMode()
    elseif not enabled and cursorActive then
        releaseGizmoCommands()
        LeaveCursorMode()
        cursorActive = false
    end
end

local function stopGizmo(cancel)
    if cancel then cancelled = true end
    gizmoEnabled = false
end

local function updateTextUI(force)
    if not gizmoEnabled then return end

    local interaction = cursorActive and 'GIZMO' or 'FREECAM'
    local signature = interaction .. ':' .. currentMode .. ':' .. tostring(localMode)
    if not force and signature == lastUiMode then return end
    lastUiMode = signature

    local status
    if cursorActive then
        localMode = localMode == true
        status = ('**%s**  •  Vänsterklick + dra  •  **W** flytta  •  **R** rotera  •  **Q** %s'):format(
            currentMode,
            localMode and 'lokal' or 'värld'
        )
    else
        status = '**FREECAM**  •  Mus titta  •  WASD flytta  •  Q/E ner/upp  •  SHIFT snabb  •  CTRL långsam  •  Scroll zoom'
    end

    lib.showTextUI((
        '**KÖRFÖRBUD – PLACERING**  \n' ..
        '%s  \n' ..
        '**ALT** växla Freecam/Gizmo  •  **ENTER** spara  •  **ESC** avbryt'
    ):format(status), {
        position = 'right-center'
    })
end

local function startFreecam()
    local gameplayPos = GetGameplayCamCoord()
    local gameplayRot = GetGameplayCamRot(2)

    camPos = vector3(gameplayPos.x, gameplayPos.y, gameplayPos.z)
    camRot = vector3(clamp(gameplayRot.x, -89.0, 89.0), 0.0, gameplayRot.z)
    camFov = clamp(GetGameplayCamFov(), FREECAM_MIN_FOV, FREECAM_MAX_FOV)

    freecam = CreateCam('DEFAULT_SCRIPTED_CAMERA', true)
    SetCamCoord(freecam, camPos.x, camPos.y, camPos.z)
    SetCamRot(freecam, camRot.x, camRot.y, camRot.z, 2)
    SetCamFov(freecam, camFov)
    SetCamActive(freecam, true)
    RenderScriptCams(true, true, 180, true, true)
end

local function stopFreecam()
    setCursor(false)
    ClearFocus()

    if freecam and DoesCamExist(freecam) then
        RenderScriptCams(false, true, 180, true, true)
        DestroyCam(freecam, false)
    end

    freecam = nil
end

local function keepCameraNearWorkArea(position)
    if not currentFocusEntity or not DoesEntityExist(currentFocusEntity) then
        return position
    end

    local focus = GetEntityCoords(currentFocusEntity)
    local delta = position - focus
    local distance = #delta

    if distance <= FREECAM_MAX_DISTANCE or distance <= 0.001 then
        return position
    end

    return focus + (delta * (FREECAM_MAX_DISTANCE / distance))
end

local function updateFreecam()
    if not freecam or not DoesCamExist(freecam) then return end

    DisableControlAction(0, 1, true)
    DisableControlAction(0, 2, true)
    DisableControlAction(0, 14, true)
    DisableControlAction(0, 15, true)
    DisableControlAction(0, 16, true)
    DisableControlAction(0, 17, true)
    DisableControlAction(0, 19, true)
    DisableControlAction(0, 21, true)
    DisableControlAction(0, 32, true)
    DisableControlAction(0, 33, true)
    DisableControlAction(0, 34, true)
    DisableControlAction(0, 35, true)
    DisableControlAction(0, 36, true)
    DisableControlAction(0, 38, true)
    DisableControlAction(0, 44, true)

    if IsDisabledControlJustPressed(0, 19) then
        setCursor(not cursorActive)
        PlaySoundFrontend(-1, 'NAV_UP_DOWN', 'HUD_FRONTEND_DEFAULT_SOUNDSET', true)
        updateTextUI(true)
    end

    if cursorActive then
        updateTextUI(false)
        return
    end

    local lookX = GetDisabledControlNormal(0, 1)
    local lookY = GetDisabledControlNormal(0, 2)
    camRot = vector3(
        clamp(camRot.x - (lookY * FREECAM_MOUSE_SENSITIVITY), -89.0, 89.0),
        0.0,
        camRot.z - (lookX * FREECAM_MOUSE_SENSITIVITY)
    )

    local dt = clamp(GetFrameTime(), 0.001, 0.05)
    local speed = FREECAM_SPEED
    if IsDisabledControlPressed(0, 21) then
        speed = speed * FREECAM_FAST_MULTIPLIER
    elseif IsDisabledControlPressed(0, 36) then
        speed = speed * FREECAM_SLOW_MULTIPLIER
    end

    local forward = rotationToDirection(camRot)
    local right = getRightVector(camRot)
    local move = vector3(0.0, 0.0, 0.0)

    if IsDisabledControlPressed(0, 32) then move = move + forward end
    if IsDisabledControlPressed(0, 33) then move = move - forward end
    if IsDisabledControlPressed(0, 35) then move = move + right end
    if IsDisabledControlPressed(0, 34) then move = move - right end
    if IsDisabledControlPressed(0, 38) then move = move + vector3(0.0, 0.0, 1.0) end
    if IsDisabledControlPressed(0, 44) then move = move - vector3(0.0, 0.0, 1.0) end

    if #move > 0.001 then
        move = move / #move
        camPos = keepCameraNearWorkArea(camPos + move * (speed * dt))
    end

    if IsDisabledControlJustPressed(0, 15) then
        camFov = clamp(camFov - FREECAM_FOV_STEP, FREECAM_MIN_FOV, FREECAM_MAX_FOV)
    elseif IsDisabledControlJustPressed(0, 14) then
        camFov = clamp(camFov + FREECAM_FOV_STEP, FREECAM_MIN_FOV, FREECAM_MAX_FOV)
    end

    SetCamCoord(freecam, camPos.x, camPos.y, camPos.z)
    SetCamRot(freecam, camRot.x, camRot.y, camRot.z, 2)
    SetCamFov(freecam, camFov)
    SetFocusPosAndVel(camPos.x, camPos.y, camPos.z, 0.0, 0.0, 0.0)
    updateTextUI(false)
end

local function makeEntityMatrix(entity)
    local forward, right, up, position = GetEntityMatrix(entity)
    local view = dataview.ArrayBuffer(64)

    view:SetFloat32(0, right.x)
        :SetFloat32(4, right.y)
        :SetFloat32(8, right.z)
        :SetFloat32(12, 0.0)
        :SetFloat32(16, forward.x)
        :SetFloat32(20, forward.y)
        :SetFloat32(24, forward.z)
        :SetFloat32(28, 0.0)
        :SetFloat32(32, up.x)
        :SetFloat32(36, up.y)
        :SetFloat32(40, up.z)
        :SetFloat32(44, 0.0)
        :SetFloat32(48, position.x)
        :SetFloat32(52, position.y)
        :SetFloat32(56, position.z)
        :SetFloat32(60, 1.0)

    return view
end

local function applyEntityMatrix(entity, view)
    local fx, fy, fz = normalize(
        view:GetFloat32(16),
        view:GetFloat32(20),
        view:GetFloat32(24)
    )
    local rx, ry, rz = normalize(
        view:GetFloat32(0),
        view:GetFloat32(4),
        view:GetFloat32(8)
    )
    local ux, uy, uz = normalize(
        view:GetFloat32(32),
        view:GetFloat32(36),
        view:GetFloat32(40)
    )

    SetEntityMatrix(
        entity,
        fx, fy, fz,
        rx, ry, rz,
        ux, uy, uz,
        view:GetFloat32(48),
        view:GetFloat32(52),
        view:GetFloat32(56)
    )
end

local function updateNativeGizmo(entity)
    if not cursorActive then return end

    local matrix = makeEntityMatrix(entity)
    local changed = Citizen.InvokeNative(
        0xEB2EDCA2,
        matrix:Buffer(),
        gizmoId,
        Citizen.ReturnResultAnyway()
    )

    if changed then
        applyEntityMatrix(entity, matrix)
    end
end

local function disablePlacementGameplayControls()
    DisableControlAction(0, 22, true)
    DisableControlAction(0, 23, true)
    DisableControlAction(0, 24, true)
    DisableControlAction(0, 25, true)
    DisableControlAction(0, 30, true)
    DisableControlAction(0, 31, true)
    DisableControlAction(0, 37, true)
    DisableControlAction(0, 44, true)
    DisableControlAction(0, 45, true)
    DisableControlAction(0, 75, true)
    DisableControlAction(0, 140, true)
    DisableControlAction(0, 141, true)
    DisableControlAction(0, 142, true)
    DisableControlAction(0, 199, true)
    DisableControlAction(0, 200, true)
    DisableControlAction(0, 201, true)
    DisableControlAction(0, 202, true)
    DisablePlayerFiring(PlayerId(), true)
end

local function gizmoLoop(entity, focusEntity)
    currentFocusEntity = focusEntity
    currentEntity = entity
    lastUiMode = nil
    localMode = false
    currentMode = 'Flytta'

    SetEntityDrawOutlineColor(255, 255, 255, 255)
    SetEntityDrawOutlineShader(0)
    SetEntityDrawOutline(entity, true)
    SetEntityAlpha(entity, 235, false)

    releaseGizmoCommands()
    startFreecam()
    updateTextUI(true)

    while gizmoEnabled and DoesEntityExist(entity) do
        Wait(0)

        if not currentFocusEntity or not DoesEntityExist(currentFocusEntity) then
            cancelled = true
            break
        end

        disablePlacementGameplayControls()
        updateFreecam()
        updateNativeGizmo(entity)

        if IsDisabledControlJustPressed(0, 200) or IsDisabledControlJustPressed(0, 202) then
            cancelled = true
            stopGizmo(true)
            PlaySoundFrontend(-1, 'CANCEL', 'HUD_FRONTEND_DEFAULT_SOUNDSET', true)
            break
        end

        if IsDisabledControlJustPressed(0, 201) then
            stopGizmo(false)
            PlaySoundFrontend(-1, 'SELECT', 'HUD_FRONTEND_DEFAULT_SOUNDSET', true)
            break
        end
    end

    releaseGizmoCommands()
    setCursor(false)
    stopFreecam()
    lib.hideTextUI()
    lastUiMode = nil

    if DoesEntityExist(entity) then
        SetEntityAlpha(entity, 255, false)
        SetEntityDrawOutline(entity, false)
    end

    currentEntity = nil
    currentFocusEntity = nil
    gizmoEnabled = false
end

function SKorforbudUseGizmo(entity, focusEntity)
    if not entity or entity == 0 or not DoesEntityExist(entity) then
        return { cancelled = true }
    end

    if not focusEntity or focusEntity == 0 or not DoesEntityExist(focusEntity) then
        focusEntity = entity
    end

    cancelled = false
    gizmoEnabled = true
    currentMode = 'Flytta'
    localMode = false
    currentEntity = entity
    currentFocusEntity = focusEntity
    cursorActive = false
    gizmoId = ('S_Korforbud_%s'):format(GetGameTimer())

    gizmoLoop(entity, focusEntity)

    if not DoesEntityExist(entity) then
        return { cancelled = true }
    end

    return {
        cancelled = cancelled,
        handle = entity,
        position = GetEntityCoords(entity),
        rotation = GetEntityRotation(entity, 2)
    }
end

exports('useGizmo', SKorforbudUseGizmo)

RegisterCommand('+s_korforbud_gizmo_select', function()
    if gizmoEnabled and cursorActive then
        ExecuteCommand('+gizmoSelect')
    end
end, false)

RegisterCommand('-s_korforbud_gizmo_select', function()
    ExecuteCommand('-gizmoSelect')
end, false)

RegisterCommand('+s_korforbud_gizmo_translate', function()
    if gizmoEnabled and cursorActive then
        currentMode = 'Flytta'
        ExecuteCommand('+gizmoTranslation')
        updateTextUI(true)
    end
end, false)

RegisterCommand('-s_korforbud_gizmo_translate', function()
    ExecuteCommand('-gizmoTranslation')
end, false)

RegisterCommand('+s_korforbud_gizmo_rotate', function()
    if gizmoEnabled and cursorActive then
        currentMode = 'Rotera'
        ExecuteCommand('+gizmoRotation')
        updateTextUI(true)
    end
end, false)

RegisterCommand('-s_korforbud_gizmo_rotate', function()
    ExecuteCommand('-gizmoRotation')
end, false)

RegisterCommand('+s_korforbud_gizmo_local', function()
    if gizmoEnabled and cursorActive then
        localMode = not localMode
        ExecuteCommand('+gizmoLocal')
        updateTextUI(true)
    end
end, false)

RegisterCommand('-s_korforbud_gizmo_local', function()
    ExecuteCommand('-gizmoLocal')
end, false)

RegisterKeyMapping('+s_korforbud_gizmo_select', 'Körförbud: välj gizmo', 'MOUSE_BUTTON', 'MOUSE_LEFT')
RegisterKeyMapping('+s_korforbud_gizmo_translate', 'Körförbud: flytta', 'keyboard', 'W')
RegisterKeyMapping('+s_korforbud_gizmo_rotate', 'Körförbud: rotera', 'keyboard', 'R')
RegisterKeyMapping('+s_korforbud_gizmo_local', 'Körförbud: lokal/värld', 'keyboard', 'Q')

AddEventHandler('onResourceStop', function(resource)
    if resource ~= GetCurrentResourceName() then return end

    cancelled = true
    gizmoEnabled = false
    releaseGizmoCommands()
    setCursor(false)
    stopFreecam()
    lib.hideTextUI()

    if currentEntity and DoesEntityExist(currentEntity) then
        SetEntityAlpha(currentEntity, 255, false)
        SetEntityDrawOutline(currentEntity, false)
    end
end)
