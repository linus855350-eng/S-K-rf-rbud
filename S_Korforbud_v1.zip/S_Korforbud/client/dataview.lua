local dataView = setmetatable({
    EndBig = '>',
    EndLittle = '<',
    Types = {
        Int8 = { code = 'i1' },
        Uint8 = { code = 'I1' },
        Int16 = { code = 'i2' },
        Uint16 = { code = 'I2' },
        Int32 = { code = 'i4' },
        Uint32 = { code = 'I4' },
        Int64 = { code = 'i8' },
        Uint64 = { code = 'I8' },
        Float32 = { code = 'f', size = 4 },
        Float64 = { code = 'd', size = 8 },
        LuaInt = { code = 'j' },
        UluaInt = { code = 'J' },
        LuaNum = { code = 'n' },
        String = { code = 'z', size = -1 },
    },
    FixedTypes = {
        String = { code = 'c' },
        Int = { code = 'i' },
        Uint = { code = 'I' },
    },
}, {
    __call = function(_, length)
        return dataView.ArrayBuffer(length)
    end
})

dataView.__index = dataView

function dataView.ArrayBuffer(length)
    return setmetatable({
        blob = string.blob(length),
        length = length,
        offset = 1,
        cangrow = true,
    }, dataView)
end

function dataView.Wrap(blob)
    return setmetatable({
        blob = blob,
        length = blob:len(),
        offset = 1,
        cangrow = true,
    }, dataView)
end

function dataView:Buffer() return self.blob end
function dataView:ByteLength() return self.length end
function dataView:ByteOffset() return self.offset end

function dataView:SubView(offset, length)
    return setmetatable({
        blob = self.blob,
        length = length or self.length,
        offset = 1 + offset,
        cangrow = false,
    }, dataView)
end

local function endianFormat(big)
    return (big and dataView.EndBig) or dataView.EndLittle
end

local function packBlob(self, offset, value, code)
    local packed = self.blob:blob_pack(offset, code, value)
    if self.cangrow or packed == self.blob then
        self.blob = packed
        self.length = packed:len()
        return true
    end
    return false
end

for label, datatype in pairs(dataView.Types) do
    if not datatype.size then
        datatype.size = string.packsize(datatype.code)
    elseif datatype.size >= 0 and string.packsize(datatype.code) ~= datatype.size then
        error(('Pack size mismatch for %s'):format(label))
    end

    dataView['Get' .. label] = function(self, offset, endian)
        offset = offset or 0
        if offset < 0 then return nil end
        local value = self.blob:blob_unpack(self.offset + offset, endianFormat(endian) .. datatype.code)
        return value
    end

    dataView['Set' .. label] = function(self, offset, value, endian)
        if offset >= 0 and value ~= nil then
            local realOffset = self.offset + offset
            local valueSize = (datatype.size < 0 and value:len()) or datatype.size
            if self.cangrow or ((realOffset + valueSize - 1) <= self.length) then
                if not packBlob(self, realOffset, value, endianFormat(endian) .. datatype.code) then
                    error('cannot grow subview')
                end
            else
                error('cannot grow dataview')
            end
        end
        return self
    end
end

for label, datatype in pairs(dataView.FixedTypes) do
    datatype.size = -1

    dataView['GetFixed' .. label] = function(self, offset, typeLength, endian)
        if offset < 0 then return nil end
        local realOffset = self.offset + offset
        if (realOffset + typeLength - 1) > self.length then return nil end
        local value = self.blob:blob_unpack(realOffset, endianFormat(endian) .. 'c' .. tostring(typeLength))
        return value
    end

    dataView['SetFixed' .. label] = function(self, offset, typeLength, value, endian)
        if offset >= 0 and value ~= nil then
            local realOffset = self.offset + offset
            if self.cangrow or ((realOffset + typeLength - 1) <= self.length) then
                if not packBlob(self, realOffset, value, endianFormat(endian) .. 'c' .. tostring(typeLength)) then
                    error('cannot grow subview')
                end
            else
                error('cannot grow dataview')
            end
        end
        return self
    end
end

SKorforbudDataView = dataView

return dataView
