local bansByPlate = {}
local spawned = {}
local placing = false

local function debugPrint(...)
    if Config.Debug then
        print('^3[S_Korforbud]^7', ...)
    end
end

local function notify(description, notifyType)
    lib.notify({
        title = 'Körförbud',
        description = description,
        type = notifyType or 'inform'
    })
end

local function trim(value)
    return (value and value:match('^%s*(.-)%s*$')) or ''
end

local function normalizePlate(plate)
    return trim(tostring(plate or '')):upper():gsub('%s+', '')
end

local function isFinite(n)
    return type(n) == 'number' and n == n and math.abs(n) < 100000.0
end

local function requestModel(model)
    local hash = type(model) == 'number' and model or joaat(model)
    if HasModelLoaded(hash) then return hash end

    RequestModel(hash)
    local expires = GetGameTimer() + Config.ModelLoadTimeout
    while not HasModelLoaded(hash) and GetGameTimer() < expires do
        Wait(0)
        RequestModel(hash)
    end

    if not HasModelLoaded(hash) then return nil end
    return hash
end

local function deleteProp(entry)
    if not entry then return end
    if entry.prop and DoesEntityExist(entry.prop) then
        DeleteEntity(entry.prop)
    end
end

local function clearSpawned()
    for vehicle, entry in pairs(spawned) do
        deleteProp(entry)
        spawned[vehicle] = nil
    end
end

local function quatMultiply(ax, ay, az, aw, bx, by, bz, bw)
    return
        aw * bx + ax * bw + ay * bz - az * by,
        aw * by - ax * bz + ay * bw + az * bx,
        aw * bz + ax * by - ay * bx + az * bw,
        aw * bw - ax * bx - ay * by - az * bz
end

local function relativeQuaternion(parent, child)
    local px, py, pz, pw = GetEntityQuaternion(parent)
    local cx, cy, cz, cw = GetEntityQuaternion(child)

    return quatMultiply(-px, -py, -pz, pw, cx, cy, cz, cw)
end

local function worldQuaternion(vehicle, ban)
    local vx, vy, vz, vw = GetEntityQuaternion(vehicle)
    return quatMultiply(
        vx, vy, vz, vw,
        tonumber(ban.qx), tonumber(ban.qy), tonumber(ban.qz), tonumber(ban.qw)
    )
end

local function findClosestVehicle(maxDistance)
    local ped = PlayerPedId()
    local coords = GetEntityCoords(ped)
    local closest, closestDistance = nil, maxDistance + 0.001

    for _, vehicle in ipairs(GetGamePool('CVehicle')) do
        if DoesEntityExist(vehicle) then
            local dist = #(coords - GetEntityCoords(vehicle))
            if dist < closestDistance then
                closest = vehicle
                closestDistance = dist
            end
        end
    end

    return closest, closestDistance
end

local function createPersistentProp(vehicle, ban)
    if spawned[vehicle] then return end

    local model = requestModel(Config.PropModel)
    if not model then
        debugPrint('Kunde inte ladda modellen', Config.PropModel)
        return
    end

    local p = GetEntityCoords(vehicle)
    local prop = CreateObjectNoOffset(model, p.x, p.y, p.z, false, false, false)
    if not prop or prop == 0 then return end

    SetEntityAsMissionEntity(prop, true, true)
    SetEntityCollision(prop, false, false)
    SetEntityInvincible(prop, true)
    FreezeEntityPosition(prop, true)

    spawned[vehicle] = {
        prop = prop,
        id = tonumber(ban.id),
        plate = ban.plate,
        model_hash = tonumber(ban.model_hash),
        ban = ban
    }

    SetModelAsNoLongerNeeded(model)
end

local function shouldKeepSpawn(vehicle, entry)
    if not DoesEntityExist(vehicle) then return false end
    if not entry.prop or not DoesEntityExist(entry.prop) then return false end

    local normalized = normalizePlate(GetVehicleNumberPlateText(vehicle))
    if normalized ~= entry.plate then return false end
    if tonumber(GetEntityModel(vehicle)) ~= tonumber(entry.model_hash) then return false end

    local currentBan = bansByPlate[entry.plate]
    return currentBan and tonumber(currentBan.id) == tonumber(entry.id)
end

local function removeSpawnedForPlate(plate)
    for vehicle, entry in pairs(spawned) do
        if entry.plate == plate then
            deleteProp(entry)
            spawned[vehicle] = nil
        end
    end
end

RegisterNetEvent('S_Korforbud:sync', function(rows)
    bansByPlate = {}
    for _, row in ipairs(rows or {}) do
        row.plate = normalizePlate(row.plate)
        bansByPlate[row.plate] = row
    end
    clearSpawned()
end)

RegisterNetEvent('S_Korforbud:upsert', function(row)
    if not row then return end
    row.plate = normalizePlate(row.plate)
    removeSpawnedForPlate(row.plate)
    bansByPlate[row.plate] = row
end)

RegisterNetEvent('S_Korforbud:removed', function(plate)
    plate = normalizePlate(plate)
    bansByPlate[plate] = nil
    removeSpawnedForPlate(plate)
end)

RegisterNetEvent('S_Korforbud:notify', function(message, notifyType)
    notify(message, notifyType)
end)

RegisterCommand('körförbud', function()
    TriggerServerEvent('S_Korforbud:requestCommand', 'place')
end, false)

RegisterCommand('korforbud', function()
    TriggerServerEvent('S_Korforbud:requestCommand', 'place')
end, false)

RegisterCommand('tabortkörförbud', function()
    TriggerServerEvent('S_Korforbud:requestCommand', 'remove')
end, false)

RegisterCommand('tabortkorforbud', function()
    TriggerServerEvent('S_Korforbud:requestCommand', 'remove')
end, false)

RegisterNetEvent('S_Korforbud:beginPlacement', function()
    if placing then
        notify('Du placerar redan ett körförbud.', 'error')
        return
    end

    local vehicle = findClosestVehicle(Config.PlaceVehicleDistance)
    if not vehicle then
        notify(('Inget fordon inom %.1f meter.'):format(Config.PlaceVehicleDistance), 'error')
        return
    end

    local plateDisplay = trim(GetVehicleNumberPlateText(vehicle))
    local plate = normalizePlate(plateDisplay)
    if plate == '' then
        notify('Fordonet saknar ett giltigt registreringsnummer.', 'error')
        return
    end

    if bansByPlate[plate] then
        notify(('Fordonet %s har redan körförbud.'):format(plateDisplay), 'error')
        return
    end

    local model = requestModel(Config.PropModel)
    if not model then
        notify('Kunde inte ladda körförbuds-propen.', 'error')
        return
    end

    placing = true

    local minDim, maxDim = GetModelDimensions(GetEntityModel(vehicle))
    local defaultPos = GetOffsetFromEntityInWorldCoords(vehicle, 0.0, 0.0, math.max(0.8, maxDim.z + 0.15))
    local preview = CreateObjectNoOffset(model, defaultPos.x, defaultPos.y, defaultPos.z, false, false, false)

    if not preview or preview == 0 then
        placing = false
        notify('Kunde inte skapa körförbuds-propen.', 'error')
        return
    end

    SetEntityAsMissionEntity(preview, true, true)
    SetEntityCollision(preview, false, false)
    SetEntityInvincible(preview, true)
    FreezeEntityPosition(preview, true)

    local vx, vy, vz, vw = GetEntityQuaternion(vehicle)
    SetEntityQuaternion(preview, vx, vy, vz, vw)

    local result = SKorforbudUseGizmo(preview, vehicle)

    if result.cancelled or not DoesEntityExist(preview) then
        if DoesEntityExist(preview) then DeleteEntity(preview) end
        placing = false
        notify('Placeringen avbröts.', 'inform')
        return
    end

    if not DoesEntityExist(vehicle) then
        DeleteEntity(preview)
        placing = false
        notify('Fordonet försvann innan körförbudet kunde sparas.', 'error')
        return
    end

    local propCoords = GetEntityCoords(preview)
    local offset = GetOffsetFromEntityGivenWorldCoords(vehicle, propCoords.x, propCoords.y, propCoords.z)
    local offsetLength = math.sqrt(offset.x * offset.x + offset.y * offset.y + offset.z * offset.z)

    if offsetLength > Config.MaxAttachmentOffset then
        DeleteEntity(preview)
        placing = false
        notify(('Propen måste vara inom %.1f meter från fordonet.'):format(Config.MaxAttachmentOffset), 'error')
        return
    end

    local qx, qy, qz, qw = relativeQuaternion(vehicle, preview)
    if not (isFinite(offset.x) and isFinite(offset.y) and isFinite(offset.z) and
            isFinite(qx) and isFinite(qy) and isFinite(qz) and isFinite(qw)) then
        DeleteEntity(preview)
        placing = false
        notify('Placeringen gav ogiltiga transformvärden.', 'error')
        return
    end

    local netId = NetworkGetNetworkIdFromEntity(vehicle)
    local vehicleModel = GetEntityModel(vehicle)

    DeleteEntity(preview)
    placing = false

    TriggerServerEvent('S_Korforbud:save', {
        net_id = netId,
        plate = plate,
        display_plate = plateDisplay,
        model_hash = vehicleModel,
        offset_x = offset.x,
        offset_y = offset.y,
        offset_z = offset.z,
        qx = qx,
        qy = qy,
        qz = qz,
        qw = qw
    })
end)

RegisterNetEvent('S_Korforbud:beginRemoval', function()
    local pedCoords = GetEntityCoords(PlayerPedId())
    local closestVehicle, closestEntry, closestDistance

    for vehicle, entry in pairs(spawned) do
        if shouldKeepSpawn(vehicle, entry) then
            local propCoords = GetEntityCoords(entry.prop)
            local dist = #(pedCoords - propCoords)
            if dist <= Config.RemoveDistance and (not closestDistance or dist < closestDistance) then
                closestVehicle = vehicle
                closestEntry = entry
                closestDistance = dist
            end
        end
    end

    if not closestEntry or not closestVehicle then
        notify(('Inget placerat körförbud inom %.1f meter.'):format(Config.RemoveDistance), 'error')
        return
    end

    TriggerServerEvent('S_Korforbud:remove', {
        id = closestEntry.id,
        plate = closestEntry.plate,
        net_id = NetworkGetNetworkIdFromEntity(closestVehicle)
    })
end)

CreateThread(function()
    Wait(1200)
    TriggerServerEvent('S_Korforbud:requestSync')
end)

RegisterNetEvent('esx:playerLoaded', function()
    Wait(1000)
    TriggerServerEvent('S_Korforbud:requestSync')
end)

CreateThread(function()
    while true do
        Wait(Config.VehicleScanInterval)

        for vehicle, entry in pairs(spawned) do
            if not shouldKeepSpawn(vehicle, entry) then
                deleteProp(entry)
                spawned[vehicle] = nil
            end
        end

        for _, vehicle in ipairs(GetGamePool('CVehicle')) do
            if DoesEntityExist(vehicle) and not spawned[vehicle] then
                local plate = normalizePlate(GetVehicleNumberPlateText(vehicle))
                local ban = bansByPlate[plate]
                if ban and tonumber(GetEntityModel(vehicle)) == tonumber(ban.model_hash) then
                    createPersistentProp(vehicle, ban)
                end
            end
        end
    end
end)

CreateThread(function()
    while true do
        local hasAny = next(spawned) ~= nil
        if not hasAny then
            Wait(350)
        else
            Wait(0)
            for vehicle, entry in pairs(spawned) do
                if shouldKeepSpawn(vehicle, entry) then
                    local ban = entry.ban
                    local pos = GetOffsetFromEntityInWorldCoords(
                        vehicle,
                        tonumber(ban.offset_x),
                        tonumber(ban.offset_y),
                        tonumber(ban.offset_z)
                    )
                    local qx, qy, qz, qw = worldQuaternion(vehicle, ban)

                    SetEntityCoordsNoOffset(entry.prop, pos.x, pos.y, pos.z, false, false, false)
                    SetEntityQuaternion(entry.prop, qx, qy, qz, qw)
                end
            end
        end
    end
end)

AddEventHandler('onResourceStop', function(resource)
    if resource ~= GetCurrentResourceName() then return end
    clearSpawned()
end)
